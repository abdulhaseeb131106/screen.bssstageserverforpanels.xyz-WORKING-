<?php $__env->startSection('title', 'Markaz Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Prayer Timings</h1>
       
    </div>
       <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"> All Prayer Timings </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <?php if($prayer): ?>
                <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead> 
                        <tr>
                            <th>Date</th>
                            <th>Fajar Azan</th>
                            <th>Fajar</th>
                            <th>Zuhr Azan</th>
                            <th>Zuhr</th>
                            <th>Asr Azan</th>
                            <th>Asr</th>
                            <th>Maghrib Azan</th>
                            <th>Maghrib</th>
                            <th>Isha Azan</th>
                            <th>Isha</th>
                            <th>Sun Rise</th>
                            <th>Chaast</th>
                            <th>Zawal</th>
                            <th>Jummua Azan</th>
                            <th>Jummua</th>
                            <th>Ijtimah</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $prayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prayers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($prayers->date); ?></td>
                            <td><?php echo e($prayers->fajar_azan); ?></td>
                            <td><?php echo e($prayers->fajar_jamat); ?></td>
                            <td><?php echo e($prayers->zuhr_azan); ?></td>
                            <td><?php echo e($prayers->zuhr_jamat); ?></td>
                            <td><?php echo e($prayers->asr_azan); ?></td>
                            <td><?php echo e($prayers->asr_jamat); ?></td>
                            <td><?php echo e($prayers->maghrib_azan); ?></td>
                            <td><?php echo e($prayers->maghrib_jamat); ?></td>
                            <td><?php echo e($prayers->isha_azan); ?></td>
                            <td><?php echo e($prayers->Isha_jamat); ?></td>
                            <td><?php echo e($prayers->sun_rise); ?></td>
                            <td><?php echo e($prayers->chaasht); ?></td>
                            <td><?php echo e($prayers->zawal); ?></td>
                            <td><?php echo e($prayers->jumah_azan); ?></td>
                            <td><?php echo e($prayers->jumua); ?></td>
                            <td><?php echo e($prayers->jumma_ijtimah); ?></td>
                            <td>
                                <div class="d-flex">

                                        <a href="<?php echo e(route('markaz_admin.delete', $prayers->id)); ?>" class="btn btn-danger btn-sm mx-2" onclick="showDeleteConfirmation(event)">
                                            <i class="fas fa-trash fa-sm"></i>
                                        </a>
                                        <a href="<?php echo e(route('markaz_admin.m_edit', ['id' => $prayers->id])); ?>" class="btn btn-primary">
                                        <i class="fas fa-edit fa-sm"></i>
                                        </a>


                                  
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                 <?php else: ?>
                <div class="alert alert-danger">No record Found!</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_for_markaz.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\screen.bssstageserverforpanels.xyz\resources\views/markaz_admin/dashboard.blade.php ENDPATH**/ ?>