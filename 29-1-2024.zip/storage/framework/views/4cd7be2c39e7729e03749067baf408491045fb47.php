
<?php $__env->startSection('title', 'Edit - User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit User</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">User Details</h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-sm">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-4">
                            <label for="">Employee ID</label>
                            <input type="text" class="form-control" name="employ_id" value="<?php echo e($user->employ_id); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="">Employee Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="">Employee Mail</label>
                            <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>">
                        </div>
                    
                    </div>
                    <div class="form-group row">
                            <div class="col-md-4">
                            <label for="">Region</label>
                            <select name="region_id" id="region" class="form-control">
                                <option value="" selected disabled>--- Select Region ---</option>
                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region->id); ?>" <?php echo e($user->region_id == $region->id ? 'selected' : ''); ?>><?php echo e($region->region_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                       <div class="col-md-4">
                            <label for="">County</label>
                            <select name="county_id" id="country" class="form-control">
                                <option value="" selected disabled>--- Select County ---</option>
                                   <?php $__currentLoopData = $counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $county): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($county->id); ?>"<?php echo e($user->county_id == $county->id ? 'selected' :''); ?>><?php echo e($county->county_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="">Centre</label>                        
                            <select name="centre_id" id="" class="form-control">
                                <option value="" selected disabled>--- Select Centre ---</option>
                                <?php $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($centre->id); ?>" <?php echo e($user->centre_id == $centre->id ? 'selected' : ''); ?> ><?php echo e($centre->centre_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4">
                            <label for="">Password</label>
                            <input type="text" class="form-control" name="password" value="">
                        </div>
                        
                    </div>
                <div class="col-md-4 pt-2">
                    <button type="submit" class="btn btn-primary btn-block mt-4">Update</button>
                </div>
            </form>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
 <script>
         $(document).ready(function () {
            $('#region').on('change',function(e) {

                var region_id = e.target.value;
                $.ajax({
                  url:"<?php echo e(route('user.dropdown')); ?>",
                  type:"POST",
                  data: {
                      region_id: region_id,
                      _token: "<?php echo e(csrf_token()); ?>"
                    },

                  success:function (data) {
                         $('#country').empty();
                    for (var i = 0; i < data.countries.length; i++) {
                         $('#country').append('<option value="'+data.countries[i].id+'">'+data.countries[i].county_name+'</option>');
                    }

                  }


              })
            });

        });
   </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/bssstageserver3/screen.bssstageserverforpanels.xyz/resources/views/user/edit.blade.php ENDPATH**/ ?>