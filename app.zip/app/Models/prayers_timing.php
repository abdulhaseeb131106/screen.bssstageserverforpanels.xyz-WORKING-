<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class prayers_timing extends Model
{
    use HasFactory;
    protected $table = 'prayers_timings';
    protected $fillable = ['fajar_jamat','zuhr_jamat','asr_jamat','maghrib_jamat','Isha_jamat','sun_rise','chaasht','zawal','jumua','jumma_ijtimah','centre_id'];
}
