<?php

namespace App\Http\Controllers;

use App\Models\logo;
use App\Models\news;
use App\Models\prayers_timing;
use App\Models\slider;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        return view('home');
    }

    public function frontend()
    {
        $prayer = prayers_timing::where('centre_id',auth()->user()->centre_id)->get();
        $new = news::where('centre_id',auth()->user()->centre_id)->get();
        $slider = slider::where('centre_id',auth()->user()->centre_id)->get();
        $logos = logo::where('centre_id',auth()->user()->centre_id)->get();
        return view('index' ,compact('prayer','new','slider','logos'));

    }




}
