<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Region;

class RegionController extends Controller
{
    public function index()
    {
    	$regions = Region::get();
        return view('region.index', compact('regions'));
    }

    public function create()
    {
    	return view('region.create');


    }

    public function store(Request $request)
    {
    	$request->validate([
            'region_name' => ['required'],
           
        ]);


        Region::create([
                'region_name' => $request->get('region_name'),
                
            ]);

        return redirect('region')->with('success', "Region Created Successfuly");
    }

    public function edit($id)
    {
    	$region = Region::find($id);
    	return view('region.edit', compact('region'));
    }

    public function update(Request $request, $id)
    {
    	$request->validate([
    		'region_name' => ['required'],
    		
    	]);

    	$region = Region::find($id);
    	$region->update([
			'region_name' => $request->get('region_name'),
            
    	]);
    	return redirect()->to('region');
    }

    public function delete($id)
    {
    	$region = Region::find($id);
    	$region->delete();
    	return redirect()->to('region');
    }
}
