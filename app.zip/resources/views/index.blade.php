<style>
    .clock {
   font-size: 3rem;

    }

</style>

<!doctype html>
<html lang="en">

<head>
  <title>screen</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="../assets_frontend/css/style.css">

  <!-- Bootstrap CSS v5.2.1 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>


        <div class="container-fluid  main">
            <div class="row">
              <div class="col-md-3 side">
                <h1>NAMAZ TIMING</h1>
                <table class="table table-borderless">
                  <thead>
                  <tr>
                  <th></th>
                  <th>AZAN</th>
                  <th>JAMAT</th>
                </tr>
            </thead>
              <tbody>
                @foreach($prayer as $prayers)
              <tr>
                <td>Fajar</td>
                <td>00:00</td>
                <td>{{$prayers->fajar_jamat}}</td>
              </tr>
              <tr>
                <td>ZUHR</td>
                <td>00:00</td>
                <td>{{$prayers->zuhr_jamat}}</td>
              </tr>
              <tr>
                <td>ASR</td>
                <td>00:00</td>
                <td>{{$prayers->asr_jamat}}</td>
              </tr>
              <tr>
                <td>MAGHRIB</td>
                <td>00:00</td>
                <td>{{$prayers->maghrib_jamat}}</td>
              </tr>
              <tr>
                <td>ISHA</td>
                <td>00:00</td>
                <td>{{$prayers->Isha_jamat}}</td>
              </tr>
              @endforeach
            </tbody>
                </table>
              </div>
              <div class="col-md-6 slider">
                <div  class="box rounded-5">
                <h3>{{ \App\Models\Centre::where('id', auth()->user()->centre_id)->value('centre_name') }}</h3>
                

              </div>
              <div  class="box0  rounded-5">
            </h1> <div id="MyClockDisplay" class="clock" onload="showTime()"></div>

              </div>
                      <div id="carouselExampleControlsNoTouching" class="carousel slide" data-bs-touch="false">
                        <div class="carousel-inner">
                            @foreach($slider as $slide)
                            <div class="carousel-item{{ $loop->first ? ' active' : '' }}">
                                <img src="/images/{{$slide->image_name}}" class="d-block rounded-4 w-100" alt="Slide{{ $loop->index }}">
                            </div>
                        @endforeach


                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="prev">
                          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="next">
                          <span class="carousel-control-next-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Next</span>
                        </button>
                      </div>

                    </div>
                <div class="col-md-3 s1 side">
                  <table class="table table-borderless">
                    @foreach($prayer as $prayers)
                <tbody>
                <tr>
                  <td>SUN RISE</td>
                  <td>{{$prayers->sun_rise}}</td>
                </tr>
                <tr>
                  <td>ISHRAQ/CHASHT</td>
                  <td>{{$prayers->chaasht}}</td>
                </tr>
                <tr>
                  <td>ZAWAL</td>
                  <td>{{$prayers->zawal}}</td>
                </tr>
                <tr>
                  <td>JUMMUA</td>
                  <td>{{$prayers->zawal}}</td>
                </tr>
                <tr>
                  <td>IJTIMA</td>
                  <td>{{$prayers->jumma_ijtimah}}</td>
                </tr>
            </tbody>
            @endforeach
                  </table>
                </div>
        </div>

        <div class="row">
          <div class="col-2 jamt rounded-pill">
            <h1>01:22:12</h1>
            <p>until Zohar jamat</p>
          </div>
          <div class="col-8 news rounded-pill">
            @foreach ($new as $news)

            <marquee><h1>{{$news->newi}} {{$news->newii}} {{$news->newiii}} {{$news->newiv}} {{$news->newiv}}</h1></marquee>
            @endforeach
        </div>

        @foreach ($logos as $logo)
          <div class="col-2 logo rounded-pill">
             <img src="/logos/{{$logo->image_name}}" alt="">
          </div>
          @endforeach
        </div>

        </div>


  <!-- Bootstrap JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
    integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
    integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
  </script>
</body>

</html>

<script>
    function showTime(){
    var date = new Date();
    var h = date.getHours(); // 0 - 23
    var m = date.getMinutes(); // 0 - 59
    var s = date.getSeconds(); // 0 - 59
    var session = "AM";

    if(h == 0){
        h = 12;
    }

    if(h > 12){
        h = h - 12;
        session = "PM";
    }

    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;

    var time = h + ":" + m + ":" + s + " " + session;
    document.getElementById("MyClockDisplay").innerText = time;
    document.getElementById("MyClockDisplay").textContent = time;

    setTimeout(showTime, 1000);

}

showTime();
</script>
