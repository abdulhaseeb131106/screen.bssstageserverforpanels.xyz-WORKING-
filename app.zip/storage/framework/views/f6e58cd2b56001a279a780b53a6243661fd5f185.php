<?php $__env->startSection('title', 'Markaz Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Markaz Admin </h1>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_for_markaz.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\screen\resources\views/markaz_admin/dashboard.blade.php ENDPATH**/ ?>