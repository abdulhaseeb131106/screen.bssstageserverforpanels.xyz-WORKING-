<?php $__env->startSection('title', 'Markaz Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Prayer</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Timing Details</h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-sm">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('markaz_admin.m_update', ['id' => $prayer->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="">Fajar Jamat</label>
                        <input type="time" class="form-control" name="fajar_jamat" value="<?php echo e($prayer->fajar_jamat); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="">Zuhr Jamat</label>
                        <input type="time" class="form-control" name="zuhr_jamat" value="<?php echo e($prayer->zuhr_jamat); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="">Asr Jamat</label>
                        <input type="time" class="form-control" name="asr_jamat" value="<?php echo e($prayer->asr_jamat); ?>">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="">Maghrib Jamat</label>
                        <input type="time" class="form-control" name="maghrib_jamat" value="<?php echo e($prayer->maghrib_jamat); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="">Isha Jamat</label>
                        <input type="time" class="form-control" name="Isha_jamat" value="<?php echo e($prayer->Isha_jamat); ?>">
                    </div>

                </div>
                <hr>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="">Sun Rise</label>
                        <input type="time" class="form-control" name="sun_rise" value="<?php echo e($prayer->sun_rise); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="">Chaasht</label>
                        <input type="time" class="form-control" name="chaasht" value="<?php echo e($prayer->chaasht); ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="">Zawal</label>
                        <input type="time" class="form-control" name="zawal" value="<?php echo e($prayer->zawal); ?>">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="">Jumua</label>
                        <input type="time" class="form-control" name="jumua" value="<?php echo e($prayer->jumua); ?>">
                    </div>
                </div>
                <hr>
                <div class="form-group row">
                    <div class="col-md-4">
                        <label for="">Jumua/Ijtimah</label>
                        <input type="time" class="form-control" name="jumma_ijtimah" value="<?php echo e($prayer->jumua); ?>">
                    </div>
                </div>

                <div class="col-md-4 pt-2">
                    <button type="submit" class="btn btn-primary btn-block mt-4">Update</button>
                </div>
            </form>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_for_markaz.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/bssstageserver3/screen.bssstageserverforpanels.xyz/resources/views/markaz_admin/m_edit.blade.php ENDPATH**/ ?>