<?php $__env->startSection('title', 'Markaz Admin'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">News</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">News </h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-sm">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('news.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group row">

                    <div class="col-md-4">
                        <label for="">News: 1 </label>
                        <input type="text" class="form-control" name="newi" value="<?php echo e(old('newsi')); ?>">
                    </div>
                        <div class="col-md-4">
                        <label for="">News: 2</label>
                        <input type="text" class="form-control" name="newii" value="<?php echo e(old('newsii')); ?>">
                    </div>
                        <div class="col-md-4">
                        <label for="">News: 3</label>
                        <input type="text" class="form-control" name="newiii" value="<?php echo e(old('newsii')); ?>">
                    </div>
            </div>
                <div class="form-group row">

                    <div class="col-md-4">
                        <label for="">News: 4 </label>
                        <input type="text" class="form-control" name="newiv" value="<?php echo e(old('newsiv')); ?>">
                    </div>
                        <div class="col-md-4">
                        <label for="">News: 5</label>
                        <input type="text" class="form-control" name="newv" value="<?php echo e(old('newsv')); ?>">
                    </div>

            </div>
            <div class="col-md-4 pt-2">
                <button type="submit" class="btn btn-primary btn-block mt-4">submit</button>
            </div>
            </form>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout_for_markaz.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\screen\resources\views/news/create.blade.php ENDPATH**/ ?>