<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Users extends Model
{
    use HasFactory;

    protected $table = 'user';
    protected $fillable = ['employee_name', 'employee_id', 'region_id', 'county_id', 'centre_id', 'username', 'password', 'date' ];

}
