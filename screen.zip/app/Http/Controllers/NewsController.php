<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Models\news;
class NewsController extends Controller
{
    public function index()
    {
    $news = news::get();
     return view('news.index' ,compact('news'));
    }


    public function edit($id)
    {
    	$news = news::find($id);
    	return view('news.edit', compact('news'));
    }
    public function create()
    {
    	return view('news.create');


    }
    public function store(Request $request)
    {
    	$request->validate([
            'newi' => ['required'],
            'newii' => ['required'],
            'newiii' => ['required'],
            'newiv' => ['required'],
            'newv' => ['required'],


        ]);
 news::create([
    'newi' => $request->get('newi'),
    'newii' => $request->get('newii'),
    'newiii' => $request->get('newiii'),
    'newiv' => $request->get('newiv'),
    'newv' => $request->get('newv'),

]);

        return redirect()->route('news.index')->with('success', "Created Successfuly");

    }

    public function update(Request $request, $id)
    {
    	$request->validate([
            'newi' => ['required'],
            'newii' => ['required'],
            'newiii' => ['required'],
            'newiv' => ['required'],
            'newv' => ['required'],
    	]);

    	$news = news::find($id);
    	$news->update([
            'newi' => $request->get('newi'),
            'newii' => $request->get('newii'),
            'newiii' => $request->get('newiii'),
            'newiv' => $request->get('newiv'),
            'newv' => $request->get('newv'),
    	]);
    	return redirect()->to('news');
    }

    public function delete($id)
    {
    	$news = news::find($id);
    	$news->delete();
    	return redirect()->to('news');
    }
}
