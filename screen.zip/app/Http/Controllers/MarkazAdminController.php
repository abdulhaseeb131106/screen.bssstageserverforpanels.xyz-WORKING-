<?php

namespace App\Http\Controllers;


use App\Models\prayers_timing;
use Illuminate\Http\Request;


class MarkazAdminController extends Controller
{
        public function m_index()
        {
            $prayer = prayers_timing::find(1);
            return view('markaz_admin.m_index',compact('prayer'));
        }


    public function m_create()
    {
    	return view('markaz_admin.m_create');

    }
    public function m_store(Request $request)
    {
    	$request->validate([
            'fajar_jamat' => ['required'],
            'zuhr_jamat' => ['required'],
            'asr_jamat' => ['required'],
            'maghrib_jamat' => ['required'],
            'Isha_jamat' => ['required'],
            'sun_rise' => ['required'],
            'chaasht' => ['required'],
            'zawal' => ['required'],
            'jumua' => ['required'],
            'jumma_ijtimah' => ['required'],
        ]);

       // Assuming PrayersTiming is your Eloquent model for prayers_timings table
 prayers_timing::create([
    'fajar_jamat' => $request->get('fajar_jamat'),
    'zuhr_jamat' => $request->get('zuhr_jamat'),
    'asr_jamat' => $request->get('asr_jamat'),
    'maghrib_jamat' => $request->get('maghrib_jamat'),
    'Isha_jamat' => $request->get('Isha_jamat'),
    'sun_rise' => $request->get('sun_rise'),
    'chaasht' => $request->get('chaasht'),
    'zawal' => $request->get('zawal'),
    'jumua' => $request->get('jumua'),
    'jumma_ijtimah' => $request->get('jumma_ijtimah'),
]);

        return redirect('markaz_admin')->with('success', "Created Successfuly");

    }

    public function m_edit($id){

    	$prayer = prayers_timing::find($id);
    	return view('markaz_admin.m_edit', compact('prayer'));
    }

    public function m_update(Request $request, $id)
    {
    	$request->validate([
    		'fajar_jamat' => ['required'],
            'zuhr_jamat' => ['required'],
            'asr_jamat' => ['required'],
            'maghrib_jamat' => ['required'],
            'Isha_jamat' => ['required'],
            'sun_rise' => ['required'],
            'chaasht' => ['required'],
            'zawal' => ['required'],
            'jumua' => ['required'],
            'jumma_ijtimah' => ['required']
    	]);

    	$prayer= prayers_timing::find($id);
    	$prayer->update([
	'fajar_jamat' => $request->get('fajar_jamat'),
    'zuhr_jamat' => $request->get('zuhr_jamat'),
    'asr_jamat' => $request->get('asr_jamat'),
    'maghrib_jamat' => $request->get('maghrib_jamat'),
    'Isha_jamat' => $request->get('Isha_jamat'),
    'sun_rise' => $request->get('sun_rise'),
    'chaasht' => $request->get('chaasht'),
    'zawal' => $request->get('zawal'),
    'jumua' => $request->get('jumua'),
    'jumma_ijtimah' => $request->get('jumma_ijtimah'),
    	]);
    	return redirect()->to('markaz_admin');
    }

    public function m_delete($id)
    {
    	$prayer = prayers_timing::find($id);
    	$prayer->delete();
    	return redirect()->to('markaz_admin.m_index');
    }
}
