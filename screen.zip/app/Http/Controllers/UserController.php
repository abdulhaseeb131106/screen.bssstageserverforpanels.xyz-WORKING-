<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\County;
use App\Models\Region;
use App\Models\Centre;
use App\Models\Users;

class UserController extends Controller
{
   public function index()
    {
    	$users = Users::join('region', 'region.id', '=', 'user.region_id')
        ->select('user.*', 'region.region_name as region_name', 'county.county_name as county_name', 'centre.centre_name as centre_name')
        ->join('county', 'county.id', '=', 'user.county_id')
        ->join('centre', 'centre.id', '=', 'user.centre_id')->get();
        return view('user.index', compact('users'));
    }

    public function create()
    {
        $regions = Region::get();
        $counties = County::get();
        $centres = Centre::get();
    	$users = Users::get();
    	return view('user.create', compact('users', 'regions', 'counties', 'centres'));


    }





public function getCounties($region_id)
{
    $counties = County::where('region_id', $region_id)->get();
    return response()->json($counties);
}



    public function store(Request $request)
    {
    	$request->validate([
            'employee_name' => ['required'],
            'employee_id' => ['required'],
            'region_id' => ['required'],
            'county_id' => ['required'],
            'centre_id' => ['required'],
            'username' => ['required'],
            'password' => ['required'],
            'date' => ['required']
        ]);

        Users::create([
            'employee_name' => request()->get('employee_name'),
    		'employee_id' => request()->get('employee_id'),
            'region_id' => request()->get('region_id'),
            'county_id' => request()->get('county_id'),
            'centre_id' => request()->get('centre_id'),
            'username' => request()->get('username'),
            'password' => request()->get('password'),
            'date' => request()->get('date')
        ]);

        return redirect('user')->with('success', "User Created Successfuly");
    }

    public function edit($id)
    {
        $regions = Region::get();
        $counties = County::get();
        $centres = Centre::get();
    	$user = Users::find($id);
    	return view('user.edit', compact('user', 'regions', 'counties', 'centres'));
    }

    public function update(Request $request, $id)
    {
    	$request->validate([
            'employee_name' => ['required'],
            'employee_id' => ['required'],
            'region_id' => ['required'],
            'county_id' => ['required'],
            'centre_id' => ['required'],
            'username' => ['required'],
            'password' => ['required'],
            'date' => ['required']
        ]);

    	$user = Users::find($id);
    	$user->update([
    		'employee_name' => request()->get('employee_name'),
    		'employee_id' => request()->get('employee_id'),
            'region_id' => request()->get('region_id'),
            'county_id' => request()->get('county_id'),
            'centre_id' => request()->get('centre_id'),
            'username' => request()->get('username'),
            'password' => request()->get('password'),
            'date' => request()->get('date')
    	]);
    	return redirect()->to('user');
    }

    public function delete($id)
    {
    	$user = Users::find($id);
    	$user->delete();
    	return redirect()->to('user');
    }
    public function dropdown(Request $request)
    {
       $countries = County::where('region_id', $request->region_id)->get();
       return response()->json(['countries' => $countries]);
    }
}
