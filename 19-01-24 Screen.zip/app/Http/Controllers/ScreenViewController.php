<?php

namespace App\Http\Controllers;



use App\Models\Sideimage;
use Illuminate\Http\Request;
use App\Models\logo;
use App\Models\news;
use App\Models\prayers_timing;
use App\Models\slider;
use App\Models\Centre;


class ScreenViewController extends Controller
{
    
     public function frontend(Request $request)
    {
        $centre_id = Centre::where('centre_slug',$request->slug)->value('id');
        $prayer = prayers_timing::where('centre_id',$centre_id)
         ->whereMonth('date', date('m'))
             ->whereDay('date', date('d'))
             ->first();
       
        $new = news::where('centre_id',$centre_id)->get();
        $side = Sideimage::first();
        $slider = slider::where('centre_id',$centre_id)->get();
        $logos = logo::where('centre_id',$centre_id)->get();
        
        
        return view('index' ,compact('prayer','new','slider','logos','centre_id','side'));

    }
       

       
}
