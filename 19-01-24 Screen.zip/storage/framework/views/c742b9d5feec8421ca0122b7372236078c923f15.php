
<?php $__env->startSection('title', 'Edit - User'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit User</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">User Details</h6>
        </div>
        <div class="card-body">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-sm">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-4">
                            <label for="">Employee Name</label>
                            <input type="text" class="form-control" name="employee_name" value="<?php echo e($user->employee_name); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="">Employee ID</label>
                            <input type="text" class="form-control" name="employee_id" value="<?php echo e($user->employee_id); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="">Region</label>                        
                            <select name="region_id" id="" class="form-control">
                                <option value="" selected disabled>--- Select Region ---</option>
                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region->id); ?>" <?php echo e($user->region_id == $region->id ? 'selected' : ''); ?>><?php echo e($region->region_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4">
                            <label for="">County</label>                        
                            <select name="county_id" id="" class="form-control">
                                <option value="" selected disabled>--- Select County ---</option>
                                <?php $__currentLoopData = $counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $county): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($county->id); ?>" <?php echo e($user->county_id == $county->id ? 'selected' : ''); ?> ><?php echo e($county->county_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="">Centre</label>                        
                            <select name="centre_id" id="" class="form-control">
                                <option value="" selected disabled>--- Select Centre ---</option>
                                <?php $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($centre->id); ?>" <?php echo e($user->centre_id == $centre->id ? 'selected' : ''); ?> ><?php echo e($centre->centre_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="">Username</label>
                            <input type="text" class="form-control" name="username" value="<?php echo e($user->username); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-4">
                            <label for="">Password</label>
                            <input type="text" class="form-control" name="password" value="<?php echo e($user->password); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="">Date</label>
                            <input type="date" class="form-control" name="date" value="<?php echo e($user->date); ?>">
                        </div>
                    </div>
                <div class="col-md-4 pt-2">
                    <button type="submit" class="btn btn-primary btn-block mt-4">Update</button>
                </div>
            </form>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\screen\resources\views/user/edit.blade.php ENDPATH**/ ?>